# MRR Tracker — Cowork Folder Instructions

This folder tracks Monthly Recurring Revenue (MRR) for Refrens from invoice data.

## Quick Commands

When Vaidik says **"Update MRR"** or **"Run MRR"**:
1. Run `python update_mrr.py` from this folder
2. The script will: pick up CSVs from `inbox/`, deduplicate against `master_invoices.csv`, append new invoices, run the full MRR calculation, and output results to `output/`
3. After the script finishes, summarize the latest month's key metrics from `output/monthly_summary.csv`: Total MRR, ARR, Active Clients, NRR%, and Net New MRR breakdown

When Vaidik says **"Recompute MRR"** (no new data, just rerun):
1. Run `python update_mrr.py --recompute-only`

When Vaidik asks about **specific clients, churn, or trends**:
1. Read the relevant CSV from `output/` and analyze

## Folder Structure

```
mrr-cowork/
├── INSTRUCTIONS.md          ← You're reading this (Cowork folder instructions)
├── update_mrr.py            ← Main pipeline script (merge + calculate)
├── master_invoices.csv      ← Full historical invoice dataset (auto-maintained)
├── scripts/
│   └── calculate_mrr.py     ← Frozen MRR methodology v1.1 (patched)
├── inbox/                   ← Drop new invoice CSVs here
│   └── processed/           ← Processed files are archived here
└── output/                  ← MRR calculation results
    ├── monthly_summary.csv  ← One row per month: MRR, movements, NRR, GRR, etc.
    ├── client_summary.csv   ← One row per client: status, revenue, products
    └── invoices_enriched.csv← Each invoice tagged with movement type
```

## Workflow

1. Export invoices from Refrens (Premium/subscription invoices only)
2. Drop the CSV into `inbox/`
3. Say "Update MRR"
4. Results appear in `output/`

The master file grows over time. Inbox files are archived after processing. Deduplication is by Invoice `ID` column — uploading the same file twice won't create duplicates.

## Expected CSV Format

Required columns: `ID`, `ClientProfile`, `Product`, `Amount` (or `AmountInINR`), `InvoiceDate` (or `InvoiceDate: Day`), `Period`

Optional columns: `Product → Name`, `SubscriptionStart`, `SubscriptionEnd` (derived from InvoiceDate + Period if missing)

Period values: WEEKLY, MONTHLY, QUARTERLY, YEARLY, 2YEARLY, 3YEARLY, 4YEARLY, 5YEARLY, LIFETIME

## Methodology

Frozen MRR methodology v1.1. See `scripts/calculate_mrr.py` header for full documentation. Key rules:
- MRR = Amount / PeriodMonths
- Overlapping subscriptions: latest invoice wins (prevents double-counting)
- Movements: NEW → EXPANSION → REACTIVATION → CONTRACTION → CHURN
- SUSPENSE_CLIENT: invoices without ClientProfile (counted in MRR totals, excluded from client metrics)
- LIFETIME amortized over 7 years (84 months)
